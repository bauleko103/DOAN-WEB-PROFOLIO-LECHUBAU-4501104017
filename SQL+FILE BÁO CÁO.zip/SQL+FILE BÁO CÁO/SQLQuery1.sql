﻿USE master
GO
-------TẠO DATABASE--------------

CREATE DATABASE BAULEPROFOLIO
go

--CHUYỂN TỚI DATABASE
USE BAULEPROFOLIO
GO

--------------------------------------- TẠO TABLE ----------------------------------------------------
------------------------------------------------------------------------------------------------------
CREATE TABLE HOME
(
	ID VARCHAR(5) PRIMARY KEY,
	HINHANHNEN NVARCHAR(200),
	TUADE1 NVARCHAR(200),
	TUADE2 NVARCHAR(200),
	TUADE3 NVARCHAR(200),
	TENNUT NVARCHAR(200),
)
GO

CREATE TABLE TRANGMODEL
(
	ID VARCHAR(200) PRIMARY KEY,
	TUADE NVARCHAR(100),
	HINHANH NVARCHAR(200),
	NOIDUNG NTEXT,
)
GO

CREATE TABLE TINTUC
(
	ID VARCHAR(200) PRIMARY KEY,
	IDTHELOAI NVARCHAR(100),
	TIEUDE NVARCHAR(100),
	NOIDUNGPHU NVARCHAR(200),
	HINHANH NVARCHAR(200),
	NOIDUNGCHINH NTEXT,
	NGAYTHANG SMALLDATETIME,
)
GO

CREATE TABLE THELOAITINTUC
(
	IDTHELOAI NVARCHAR(100) PRIMARY KEY,
	TENTHELOAI NVARCHAR(100),
)
GO

CREATE TABLE LOGOKHACHHANG
(
	ID VARCHAR(200) PRIMARY KEY,
	HINHANH NVARCHAR(200),
	LINKLOGO NVARCHAR(200),
	TENLOGO NVARCHAR(200),
)
GO

CREATE TABLE CHANTRANG
(
	ID VARCHAR(200) PRIMARY KEY,
	NOIDUNG NTEXT,
	HINHANHLOGO NVARCHAR(200),
)
GO

CREATE TABLE LIENHE
(
	ID VARCHAR(200) PRIMARY KEY,
	TUADE NVARCHAR (200),
	HOTLINE NVARCHAR(50),
	ADDRESSS NVARCHAR(50),
	PHONE NVARCHAR(200),
	FAX NCHAR (200),
	WEB NVARCHAR(200),
	EMAIL NVARCHAR(200),
	TUADECHANTRANG NVARCHAR(200),
)
GO

CREATE TABLE DSKHACHHANG
(
	ID VARCHAR(200) PRIMARY KEY,
	TENKH NVARCHAR(200),
	GMAIL NVARCHAR(100),
)
GO

CREATE TABLE TAIKHOAN
(
	IDTAIKHOAN VARCHAR(50) CONSTRAINT PK_TAIKHOAN PRIMARY KEY (IDTAIKHOAN),
	PASS VARCHAR(255),
)
GO

CREATE TABLE PHOTO
(
	ID VARCHAR(200) PRIMARY KEY,
	SOTHUTU NVARCHAR(50),
	HINHANH NVARCHAR(200),
)
GO

CREATE TABLE MUCLINK
(
	ID VARCHAR(5) PRIMARY KEY,
	EMAIL NVARCHAR(200),
	PHONE NVARCHAR(200),
	LINKFB NVARCHAR(200),
	LINKPRIN NVARCHAR(200),
	LINKTWI NVARCHAR(200),
	LINKINS NVARCHAR(200),
	LINKYB NVARCHAR(200),
	LINKINK NVARCHAR(200),
)
GO

CREATE TABLE THUVIENANH
(
ID VARCHAR(200) PRIMARY KEY,
IDTHELOAI NVARCHAR(200),
HINHANH NVARCHAR(200),
)
GO



CREATE TABLE THELOAITHUVIEN
(
IDTHELOAI NVARCHAR(200) PRIMARY KEY,
THELOAIANH NVARCHAR(50),
)
GO

--/////////////////////khoá ngoiạo//////////////
ALTER TABLE dbo.TINTUC
ADD CONSTRAINT FK_TINTUC_THELOAITINTUC
		FOREIGN KEY (IDTHELOAI)
		REFERENCES dbo.THELOAITINTUC(IDTHELOAI)
GO
ALTER TABLE dbo.THUVIENANH	
ADD CONSTRAINT FK_THUVIENANH_THELOAITHUVIEN
		FOREIGN KEY (IDTHELOAI)
		REFERENCES dbo.THELOAITHUVIEN(IDTHELOAI)
GO


--nhập dữ liệu---
SET DATEFORMAT DMY
GO
INSERT dbo.HOME
        ( ID ,
          HINHANHNEN ,
          TUADE1 ,
          TUADE2 ,
          TUADE3 ,
          TENNUT
        )
VALUES  ( '01' , -- ID - varchar(5)
          N'123.JPG' , -- HINHANHNEN - nvarchar(50)
          N'AAA' , -- TUADE1 - nvarchar(200)
          N'AAA' , -- TUADE2 - nvarchar(200)
          N'AAA' , -- TUADE3 - nvarchar(200)
          N'AAA'  -- TENNUT - nvarchar(200)
        )
GO    

INSERT dbo.LOGOKHACHHANG
        ( ID, HINHANH, LINKLOGO, TENLOGO )
VALUES  ( '012', -- ID - varchar(200)
          N'123.JPG', -- HINHANH - nvarchar(200)
          N'AAA', -- LINKLOGO - nvarchar(200)
          N'AAA'  -- TENLOGO - nvarchar(200)
          )
GO

INSERT dbo.CHANTRANG
        ( ID, NOIDUNG, HINHANHLOGO )
VALUES  ( '013', -- ID - varchar(200)
          NULL, -- NOIDUNG - ntext
          N'1213.JPG'  -- HINHANHLOGO - nvarchar(200)
          )
GO

INSERT dbo.THUVIENANH
        ( ID, IDTHELOAI, HINHANH )
VALUES  ( '01', -- ID - varchar(200)
          N'001', -- IDTHELOAI - nvarchar(200)
          N'123.JPG'  -- HINHANH - nvarchar(50)
          )
GO

INSERT dbo.THELOAITHUVIEN
        ( IDTHELOAI, THELOAIANH )
VALUES  ( N'0021', -- IDTHELOAI - nvarchar(200)
          N'NTT'  -- THELOAIANH - nvarchar(50)
          )
GO

INSERT dbo.TINTUC
        ( ID ,
          IDTHELOAI ,
          TIEUDE ,
          NOIDUNGPHU ,
          HINHANH ,
          NOIDUNGCHINH ,
          NGAYTHANG
        )
VALUES  ( '010' , -- ID - varchar(200)
          N'001' , -- IDTHELOAI - nvarchar(100)
          N'AAA' , -- TIEUDE - nvarchar(100)
          N'AAA' , -- NOIDUNGPHU - nvarchar(200)
          N'123.JPG' , -- HINHANH - nvarchar(50)
          NULL , -- NOIDUNGCHINH - ntext
          '22/09/2019'  -- NGAYTHANG - smalldatetime
        )
GO

INSERT dbo.THELOAITINTUC
        ( IDTHELOAI, TENTHELOAI )
VALUES  ( N'0013', -- IDTHELOAI - nvarchar(100)
          N'TT30'  -- TENTHELOAI - nvarchar(100)
          )
GO

INSERT dbo.LIENHE
        ( ID ,
          TUADE ,
          HOTLINE ,
          ADDRESSS ,
          PHONE ,
          FAX ,
          WEB ,
          EMAIL ,
          TUADECHANTRANG
        )
VALUES  ( '031' , -- ID - varchar(200)
          N'AAA' , -- TUADE - nvarchar(200)
          N'00000' , -- HOTLINE - nvarchar(50)
          N'AAA' , -- ADDRESSS - nvarchar(50)
          N'00000' , -- PHONE - nvarchar(200)
          N'00000' , -- FAX - nchar(200)
          N'AAA' , -- WEB - nvarchar(200)
          N'AAA' , -- EMAIL - nvarchar(200)
          N'AAA'  -- TUADECHANTRANG - nvarchar(200)
        )
go
INSERT dbo.DSKHACHHANG
        ( ID, TENKH, GMAIL )
VALUES  ( 'B01', -- ID - varchar(200)
          N'NGUYEN VAN TEO', -- TENKH - nvarchar(200)
          N'AAA'  -- GMAIL - nvarchar(100)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B02', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B02', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B03', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B04', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B05', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B06', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B07', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B08', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B09', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B010', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B011', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go
INSERT dbo.PHOTO
        ( ID, SOTHUTU, HINHANH )
VALUES  ( 'B012', -- ID - varchar(200)
          N'001', -- SOTHUTU - nvarchar(50)
          N'123.JPG'  -- HINHANH - nvarchar(200)
          )
go

INSERT dbo.CHANTRANG
        ( ID, NOIDUNG, HINHANHLOGO )
VALUES  ( 'C01', -- ID - varchar(200)
          NULL, -- NOIDUNG - ntext
          N'123.JPG'  -- HINHANHLOGO - nvarchar(200)
          )
GO
INSERT dbo.TAIKHOAN
        ( IDTAIKHOAN, PASS )
VALUES  ( 'admin', -- IDTAIKHOAN - varchar(50)
          '123'  -- PASS - varchar(255)
          )
GO

INSERT dbo.TRANGMODEL
		(ID,TUADE,HINHANH,NOIDUNG)
VALUES ('A001',--ID
		'aaaa',--TUA DE
		'123.jpg',--HINH ANH
		'ASDJKFHLASKDF'--NOIDUNG
		)
GO
INSERT dbo.TRANGMODEL
		(ID,TUADE,HINHANH,NOIDUNG)
VALUES ('A002',--ID
		'aaaa',--TUA DE
		'123.jpg',--HINH ANH
		'ASDJKFHLASKDF'--NOIDUNG
		)
GO
INSERT dbo.MUCLINK
		(ID,EMAIL,PHONE,LINKFB,LINKPRIN,LINKTWI,LINKINS,LINKYB,LINKINK)
		VALUES 
		('A002',--ID
		'aaaa',--LINK
		'aaaa',--LINK
		'aaaa',--LINK
		'aaaa',--LINK
		'aaaa',--LINK
		'aaaa',--LINK
		'aaaa',--LINK
		'aaaa'--LINK
		)

GO
